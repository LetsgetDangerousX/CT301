package cs250.exercises;

import java.util.Random;
import java.util.Scanner;

public class Exercise3 {

    public static void main (String[] args) {
        Random random = new Random();

        // 1. gen a float in the range (10.50, 100.75) inclusive

            float randomFloat = 10.50f + random.nextFloat() * (100.75f - 10.50f);

        // 2. gen an int in the range (10,20) inclusive

            int randomInt = random.nextInt(11) + 10; 

        //Print integer 1st and then float

            System.out.println(randomInt);

            System.out.println(randomFloat);

        // Use scanner class to read 2 inputs * use NextLine, nextLine, and close

            Scanner scanner = new Scanner(System.in);

            float input1 = 0;
            float input2 = 0;

            if(scanner.hasNextLine()) {
                input1 = Float.parseFloat(scanner.nextLine());
            }
            if(scanner.hasNextLine()) {
                input2 = Float.parseFloat(scanner.nextLine());
            }

            scanner.close();

        // ADD all 4 vals and print sum

        float sumVals = randomInt + randomFloat + input1 + input2;

        System.out.println(sumVals);

    }
}