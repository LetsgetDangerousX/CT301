package cs250.exercises;

public class Exercise2 {

    public static void main(String [] args) {
        String arg0 = args[0];
        String arg1 = args[1];
        String arg2 = args[2];

        int intVal = Integer.parseInt(arg0);
        float floatVal = Float.parseFloat(arg1);
        long longVal = Long.parseLong(arg2);

        System.out.println(arg0);
        System.out.println(arg1);
        System.out.println(arg2);
        System.out.println(intVal + floatVal + longVal);
        System.out.println(intVal - floatVal - longVal);
        System.out.println(intVal * floatVal * longVal);
        System.out.println(intVal / floatVal / longVal);
        System.out.println(Math.pow(floatVal, intVal));
        System.out.println(longVal % intVal);
        System.out.println(longVal / -floatVal);

    }
}