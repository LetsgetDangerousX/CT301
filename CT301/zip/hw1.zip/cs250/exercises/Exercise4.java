package cs250.exercises;

public class Exercise4 {

    public static void main(String[] args ){

        // read each arg thru command line SIX characters

        if(args.length != 6) {
            System.out.println("Error: Enter 6 arguments");
            return;
        }

        // print in same order
        // 1. all characters concatanated together

        String concat = args[0] + args[1] + args[2] + args[3] + args[4] + args[5];
        System.out.println(concat);

        // 2. the count of 'a' in the concatanated string

        int CountA = 0;
        CountA += (args[0].length() - args[0].replace("a","").length());
        CountA += (args[1].length() - args[1].replace("a","").length());
        CountA += (args[2].length() - args[2].replace("a","").length());
        CountA += (args[3].length() - args[3].replace("a","").length());
        CountA += (args[4].length() - args[4].replace("a","").length());
        CountA += (args[5].length() - args[5].replace("a","").length());
        System.out.println(CountA);

        // 3. the concat string in all uppercase

        System.out.println(concat.toUpperCase());

        // 4. the concat string in all lowercase

        System.out.println(concat.toLowerCase());

        // 5. the concat string from index 1 to index 5

        System.out.println(concat.substring(1, 6));

        // 6. the concat string without the character at index 2

        System.out.println(concat.substring(0, 2) + concat.substring(3));

        // 7. the concat string where all .(dot) is replaced with _ (underscore)

        System.out.println(concat.replace(".","_"));

        // 8. the last index of the character 'e' in the concat string

        System.out.println(concat.lastIndexOf('e'));

        // 9. the concat string in reverse

        
        String Reverse = "" +
        concat.charAt(5) +
        concat.charAt(4) +
        concat.charAt(3) +
        concat.charAt(2) +
        concat.charAt(1) +
        concat.charAt(0);

        System.out.println(Reverse);

        // 10. the sum of the ASCII vals of all char as an integer

        int ASCIIsum = 
            concat.charAt(0) +
            concat.charAt(1) +
            concat.charAt(2) +
            concat.charAt(3) +
            concat.charAt(4) +
            concat.charAt(5);

            System.out.println(ASCIIsum);

    }


}