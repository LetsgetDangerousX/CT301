
package cs250.exercises;

import java.util.Arrays;
import java.util.Random;

public class Exercise6{

    public static void main(String[] args) {

//Read three arguments in command line
        if (args.length != 3) {
            throw new IllegalArgumentException("Exactly three arguments required: type, x, y");
        }

// Setting type to first arg to be used for the switch cases
        String type = args[0]; 
        int x = Integer.parseInt(args[1]);
        int y = Integer.parseInt(args[2]);

        Random random = new Random();

//Switch cases for int, float, char
        switch (type) {
            case "int": {
                int[][] array= {
                    {random.nextInt(), random.nextInt(), random.nextInt()},
                    {random.nextInt(), random.nextInt(), random.nextInt()},
                    {random.nextInt(), random.nextInt(), random.nextInt()},
                    {random.nextInt(), random.nextInt(), random.nextInt()}
                };
                printIntResults(array, x, y); // calling print method
                break;
            }
            case "float": {
                float[][] array = {
                    {random.nextFloat(), random.nextFloat(), random.nextFloat()},
                    {random.nextFloat(), random.nextFloat(), random.nextFloat()},
                    {random.nextFloat(), random.nextFloat(), random.nextFloat()},
                    {random.nextFloat(), random.nextFloat(), random.nextFloat()}
                };
                printFloatResults(array, x, y); // calling print method
                break;
            }
            case "char": {
                char[][] array = {
                    {randomChar(random), randomChar(random), randomChar(random)},
                    {randomChar(random), randomChar(random), randomChar(random)},
                    {randomChar(random), randomChar(random), randomChar(random)},
                    {randomChar(random), randomChar(random), randomChar(random)}
                };
                printCharResults(array, x, y);      //calling print method
                break;
            }

            default:    // ERROR catch in default switch
            throw new IllegalArgumentException("Invalid type. Use 'int', 'float, or 'char");
        }
    }

// preventing chinese/japanese..etc characters from randomizing. 
    private static char randomChar(Random random) {
        if(random.nextBoolean()) {

// generating only A - Z
        return (char) (random.nextInt(26) + 'A'); 
        }else{
            
//generating only a -z 
            return(char)(random.nextInt(26)+ 'a'); 
    }
    }

//Print the Int Array Method
    private static void printIntResults(int[][] array, int x, int y) {

// 1st Print
        System.out.println(Arrays.deepToString(array)); 
        
// 2nd Print
        System.out.println(array[x][y]);    

// preventing out of bounds in case a negative # populates
        int rowIndex = Math.max(0, x - y); 

//Select Row for final print
        int[] selectedRow = Arrays.copyOf(array[rowIndex], array[rowIndex].length);
        Arrays.sort(selectedRow);

// 3rd Print
        System.out.println(Arrays.toString(selectedRow)); 
    }

//Print the Float Array Method
   private static void printFloatResults(float[][] array, int x, int y) {

// 1st Print
    System.out.println(Arrays.deepToString(array)); 

// 2nd Print
    System.out.println(array[x][y]); 

// out of bounds prevention
    int rowIndex = Math.max(0, x - y);

//Select Row for final print
    float[] selectedRow = Arrays.copyOf(array[rowIndex], array[rowIndex].length);
    Arrays.sort(selectedRow);

// 3rd print
    System.out.println(Arrays.toString(selectedRow)); 
   }

//Print the Char Array Method
    private static void printCharResults(char[][] array, int x, int y) {

// 1st Print
        System.out.println(Arrays.deepToString(array)); 

// 2nd Print
        System.out.println(array[x][y]);    

// out of bounds prevention
        int rowIndex = Math.max(0, x - y); 

//Select Row for final print
        char[] selectedRow = Arrays.copyOf(array[rowIndex], array[rowIndex].length);
        Arrays.sort(selectedRow);

// 3rd print
        System.out.println(Arrays.toString(selectedRow)); 
    }

} 