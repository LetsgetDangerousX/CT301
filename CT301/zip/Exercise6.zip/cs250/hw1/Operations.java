package cs250.hw1;

public class Operations{

    public static void main(String[] args) {
        // Task one: 
        if(args.length != 3) {
            System.out.println("Error: incorrect number of arguments provided- try again");
            System.exit(1);
        }
        
    
        // Task two
        int[] numbers = new int[3]; // array to store values

        for(int i = 0; i < 3; i++) {
            String arg = args[i];
        }
        }
    }
